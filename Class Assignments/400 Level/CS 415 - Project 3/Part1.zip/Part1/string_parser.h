#ifndef STRING_PARSER_H
#define STRING_PARSER_H

#include <stdio.h>


typedef struct {
    char** command_array;  
    int int_command;      
} parseing;


parseing parser_string(char* transaction_line);
void free_command(parseing* parsed);

#endif 

