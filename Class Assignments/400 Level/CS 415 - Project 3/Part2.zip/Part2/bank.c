#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include "account.h"
#include "string_parser.h"

 int int_accounts;
 account accounts[16];
typedef struct {
    account* accounts;
    int int_accounts;
} update_args;
// Function to process a single transaction
void process_transaction(char* transaction_line, account* accounts, int total_accounts) 
{
    parseing parsed = parser_string(transaction_line);

    if (parsed.int_command == 0) 
    {
        free_command(&parsed);
        return;
    }

    char operation_type = parsed.command_array[0][0];
    switch (operation_type) 
    {
        case 'D': 
            // Deposit case
            if (parsed.int_command == 4) 
            {
                char* src_account = parsed.command_array[1];
                char* password = parsed.command_array[2];
                double amount = atof(parsed.command_array[3]);
                for (int i = 0; i < total_accounts; i++) 
                {
                    if (strcmp(accounts[i].account_number, src_account) == 0 && strcmp(accounts[i].password, password) == 0) 
                    {
                        pthread_mutex_lock(&accounts[i].ac_lock);
                        accounts[i].balance += amount;
                        accounts[i].transaction_tracker += amount;
                        pthread_mutex_unlock(&accounts[i].ac_lock);
                        break;
                    }
                }
            }
            break;

        case 'W': 
            // Withdraw case
            if (parsed.int_command == 4) 
            {
                char* src_account = parsed.command_array[1];
                char* password = parsed.command_array[2];
                double amount = atof(parsed.command_array[3]);
                for (int i = 0; i < total_accounts; i++) 
                {
                    if (strcmp(accounts[i].account_number, src_account) == 0 && strcmp(accounts[i].password, password) == 0) 
                    {
                        pthread_mutex_lock(&accounts[i].ac_lock);
                        accounts[i].balance -= amount;
                        accounts[i].transaction_tracker += amount;
                        pthread_mutex_unlock(&accounts[i].ac_lock);
                        break;
                    }
                }
            }
            break;

        case 'T':  
            // Transfer case
            if (parsed.int_command == 5) 
            {
                char* src_account = parsed.command_array[1];
                char* password = parsed.command_array[2];
                char* dest_account = parsed.command_array[3];
                double amount = atof(parsed.command_array[4]);
                for (int i = 0; i < total_accounts; i++) 
                {
                    if (strcmp(accounts[i].account_number, src_account) == 0 && strcmp(accounts[i].password, password) == 0) 
                        {
                        for (int j = 0; j < total_accounts; j++) 
                        {
                            if (strcmp(accounts[j].account_number, dest_account) == 0) {
                                pthread_mutex_lock(&accounts[i].ac_lock);
                                accounts[i].balance -= amount;
                                accounts[j].balance += amount;
                                accounts[i].transaction_tracker += amount;
				//printf("%.2f\n", accounts[i].transaction_tracker);
                                pthread_mutex_unlock(&accounts[i].ac_lock);
                                break;
                            }
                        }
                        break;
                    }
                }
            }
            break;

        case 'C':  
            // Check Balance case
            if (parsed.int_command == 3) 
            {
                char* src_account = parsed.command_array[1];
                char* password = parsed.command_array[2];
                for (int i = 0; i < total_accounts; i++) 
                {
                    if (strcmp(accounts[i].account_number, src_account) == 0 && strcmp(accounts[i].password, password) == 0) 
                    {
                        
                        break;
                    }
                }
            }
            break;

        default:
            fprintf(stderr, "Error: Invalid operation %c\n", operation_type);
            break;
    }

    free_command(&parsed);
}

void* update_balance(void* args) 
{
    update_args* arguments = (update_args*)args;
    account* accounts = arguments->accounts;
    int int_accounts = arguments->int_accounts;

    for (int i = 0; i < int_accounts; i++) 
    {
        double updated = accounts[i].reward_rate * accounts[i].transaction_tracker;
        pthread_mutex_lock(&accounts[i].ac_lock);
        if (updated != 0.0) 
        {
            accounts[i].balance += updated;
            accounts[i].transaction_tracker = 0.0;
        }
        pthread_mutex_unlock(&accounts[i].ac_lock);
    }
    return NULL;
}


int main(int argc, char* argv[]) 
{
    if (argc != 2) 
    {
        return 1;
    }

    // Opening the input file
    FILE* input_file = fopen(argv[1], "r");
    if (!input_file) 
    {
        perror("Error opening file");
        return 1;
    }


   
    fscanf(input_file, "%d\n", &int_accounts);


    account* accounts = malloc(int_accounts * sizeof(account));
    if (!accounts) 
    {
        perror("Error from allocating account memory");
        fclose(input_file);
        return 1;
    }

    
    for (int i = 0; i < int_accounts; i++)
    {
	fscanf(input_file, "index %d\n", &i);
        fscanf(input_file, "%s\n", accounts[i].account_number);
        fscanf(input_file, "%s\n", accounts[i].password);
        fscanf(input_file, "%lf\n", &accounts[i].balance);
        fscanf(input_file, "%lf\n", &accounts[i].reward_rate);
	

	accounts[i].transaction_tracker = 0.0;
	//pthread_mutex_init(&accounts[i].ac_lock, NULL);
	snprintf(accounts[i].out_file, sizeof(accounts[i].out_file), "account_%s.txt", accounts[i].account_number);
		//printf("%d : %.2f * %.2f\n", i, accounts[i].reward_rate, accounts[i].transaction_tracker);
    }
    char line[256];

    while (fgets(line, sizeof(line), input_file))
    {
	line[strcspn(line, "\n")] = '\0';
	process_transaction(line, accounts, int_accounts);
     }
  
    
    fclose(input_file);
    pthread_t update_thread;
    update_args args = {accounts, int_accounts};
    pthread_create(&update_thread, NULL, update_balance, &args);
    pthread_join(update_thread, NULL);
    
    FILE* output_file = fopen("output.txt", "w");
    if (!output_file) 
    {
        perror("Error creating output file");
        free(accounts);
        return 1;
    }

    for (int i = 0; i < int_accounts; i++) 
    {
        fprintf(output_file, "%d balance:  $%.2f\n", i, accounts[i].balance);
        pthread_mutex_destroy(&accounts[i].ac_lock);
    }

    fclose(output_file);
    free(accounts);

    printf("Transactions processed\n");
    return 0;
}
