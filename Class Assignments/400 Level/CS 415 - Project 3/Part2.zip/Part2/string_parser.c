#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "string_parser.h"


parseing parser_string(char* transaction_line) {
    parseing parsed;
    parsed.command_array = malloc(10 * sizeof(char*)); 
    if (!parsed.command_array) {
        perror("Memory allocation failed");
        parsed.int_command = 0;
        return parsed;
    }

    char* token = strtok(transaction_line, " ");  
    int command_index = 0;
    while (token != NULL) {
        parsed.command_array[command_index] = malloc(strlen(token) + 1);
        if (!parsed.command_array[command_index]) {
            perror("Memory allocation failed");
            parsed.int_command = 0;
            return parsed;
        }
        strcpy(parsed.command_array[command_index], token);
        command_index++;
        token = strtok(NULL, " ");
    }
   
    parsed.int_command = command_index; 
    return parsed;
}


void free_command(parseing* parsed) {
    for (int i = 0; i < parsed->int_command; i++) {
        free(parsed->command_array[i]);
    }
    free(parsed->command_array);
}
