#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include "account.h"
#include "string_parser.h"

#define THRESHOLD 5000 
#define WORKER_THREADS 10

typedef struct {
    account* accounts;
    int int_accounts;
    pthread_mutex_t* transaction_counter_lock;
    pthread_cond_t* bank_condition;
    pthread_cond_t* worker_condition;
    int* transaction_counter;
    int* active_workers;
} shared_data;

typedef struct {
    shared_data* shared;
    int start_index;
    int end_index;
    char** transactions;
} worker_args;


void process_transaction(char* transaction_line, account* accounts, int total_accounts, int* valid_transactions) {
    parseing parsed = parser_string(transaction_line);

    if (parsed.int_command == 0) {
        free_command(&parsed);
        return;
    }

    char operation_type = parsed.command_array[0][0];
    char *src_account, *password, *dest_account;
    double amount;
    int transaction_valid = 0;

    switch (operation_type) {
        case 'D':  // Deposit
            if (parsed.int_command == 4) {
                src_account = parsed.command_array[1];
                password = parsed.command_array[2];
                amount = atof(parsed.command_array[3]);

                for (int i = 0; i < total_accounts; i++) {
                    if (strcmp(accounts[i].account_number, src_account) == 0 &&
                        strcmp(accounts[i].password, password) == 0) {
                        pthread_mutex_lock(&accounts[i].ac_lock);
                        accounts[i].balance += amount;
                        accounts[i].transaction_tracker += amount;
                        transaction_valid = 1;
                        pthread_mutex_unlock(&accounts[i].ac_lock);
                        break;
                    }
                }
            }
            break;

        case 'W':  // Withdraw
            if (parsed.int_command == 4) {
                src_account = parsed.command_array[1];
                password = parsed.command_array[2];
                amount = atof(parsed.command_array[3]);

                for (int i = 0; i < total_accounts; i++) {
                    if (strcmp(accounts[i].account_number, src_account) == 0 &&
                        strcmp(accounts[i].password, password) == 0) {
                        pthread_mutex_lock(&accounts[i].ac_lock);
                        if (accounts[i].balance >= amount) {
                            accounts[i].balance -= amount;
                            accounts[i].transaction_tracker += amount;
                            transaction_valid = 1;
                        }
                        pthread_mutex_unlock(&accounts[i].ac_lock);
                        break;
                    }
                }
            }
            break;

        case 'T':  // Transfer
            if (parsed.int_command == 5) {
                src_account = parsed.command_array[1];
                password = parsed.command_array[2];
                dest_account = parsed.command_array[3];
                amount = atof(parsed.command_array[4]);

                for (int i = 0; i < total_accounts; i++) {
                    if (strcmp(accounts[i].account_number, src_account) == 0 &&
                        strcmp(accounts[i].password, password) == 0) {
                        for (int j = 0; j < total_accounts; j++) {
                            if (strcmp(accounts[j].account_number, dest_account) == 0) {
                                pthread_mutex_lock(&accounts[i].ac_lock);
                                if (accounts[i].balance >= amount) {
                                    accounts[i].balance -= amount;
                                    accounts[j].balance += amount;
                                    accounts[i].transaction_tracker += amount;
                                    transaction_valid = 1;
                                }
                                pthread_mutex_unlock(&accounts[i].ac_lock);
                                break;
                            }
                        }
                        break;
                    }
                }
            }
            break;

        case 'C':  // Check Balance
            break;

        default:
            fprintf(stderr, "Error: Invalid operation %c\n", operation_type);
            break;
    }

    if (transaction_valid) {
        (*valid_transactions)++;
    }

    free_command(&parsed);
}


void* worker_thread(void* args) {
    worker_args* arguments = (worker_args*)args;
    shared_data* shared = arguments->shared;
    account* accounts = shared->accounts;
    int* transaction_counter = shared->transaction_counter;
    int valid_transactions = 0;

    for (int i = arguments->start_index; i < arguments->end_index; i++) {
        process_transaction(arguments->transactions[i], accounts, shared->int_accounts, &valid_transactions);

        pthread_mutex_lock(shared->transaction_counter_lock);
        *transaction_counter += valid_transactions;
        if (*transaction_counter >= THRESHOLD) {
            pthread_cond_signal(shared->bank_condition);
            pthread_cond_wait(shared->worker_condition, shared->transaction_counter_lock);
        }
        pthread_mutex_unlock(shared->transaction_counter_lock);
    }

    pthread_mutex_lock(shared->transaction_counter_lock);
    (*shared->active_workers)--;
    pthread_mutex_unlock(shared->transaction_counter_lock);
	free(arguments);
    return NULL;
}


void* bank_thread(void* args) {
    shared_data* shared = (shared_data*)args;
    account* accounts = shared->accounts;

    while (1) {
        pthread_mutex_lock(shared->transaction_counter_lock);
        while (*shared->transaction_counter < THRESHOLD && *shared->active_workers > 0) {
            pthread_cond_wait(shared->bank_condition, shared->transaction_counter_lock);
        }

        if (*shared->active_workers == 0 && *shared->transaction_counter < THRESHOLD) {
            pthread_mutex_unlock(shared->transaction_counter_lock);
            break;
        }
	double previous_balance;
        for (int i = 0; i < shared->int_accounts; i++) {
            pthread_mutex_lock(&accounts[i].ac_lock);
            accounts[i].balance += accounts[i].reward_rate * accounts[i].transaction_tracker;
            accounts[i].transaction_tracker = 0.0;
	    
	    FILE *act_file = fopen(accounts[i].out_file, "a");
	    if (act_file)
	    {
		if (i == 0 || accounts[i].balance != previous_balance)
		{
		fprintf(act_file, "balance after update: $%.2f\n", accounts[i].balance);
		previous_balance = accounts[i].balance;
		fclose(act_file);
		}
	    }
	    
            pthread_mutex_unlock(&accounts[i].ac_lock);
        }

        *shared->transaction_counter = 0;
        pthread_cond_broadcast(shared->worker_condition);
        pthread_mutex_unlock(shared->transaction_counter_lock);
    }

    return NULL;
}
int main(int argc, char* argv[]) {
    if (argc != 2) {
        
        return 1;
    }

   
    FILE* input_file = fopen(argv[1], "r");
    if (!input_file) {
        perror("Cant open input file");
        return 1;
    }

  
    int int_accounts;
    fscanf(input_file, "%d\n", &int_accounts);

    
    account* accounts = malloc(int_accounts * sizeof(account));
    if (!accounts) {
        fclose(input_file);
        return 1;
    }

  
    for (int i = 0; i < int_accounts; i++) {
        fscanf(input_file, "index %d\n", &i);
        fscanf(input_file, "%s\n", accounts[i].account_number);
        fscanf(input_file, "%s\n", accounts[i].password);
        fscanf(input_file, "%lf\n", &accounts[i].balance);
        fscanf(input_file, "%lf\n", &accounts[i].reward_rate);

        accounts[i].transaction_tracker = 0.0;
        pthread_mutex_init(&accounts[i].ac_lock, NULL);
        snprintf(accounts[i].out_file, sizeof(accounts[i].out_file), "account_%s.txt", accounts[i].account_number);
    }


    char** transactions = NULL;
    int transaction_count = 0;
    char line[256];

    while (fgets(line, sizeof(line), input_file)) {
        line[strcspn(line, "\n")] = '\0';
        transactions = realloc(transactions, sizeof(char*) * (transaction_count + 1));
        transactions[transaction_count] = strdup(line);
        transaction_count++;
    }
    fclose(input_file);

    
    int transaction_counter = 0;
    int active_workers = WORKER_THREADS;

    pthread_mutex_t transaction_counter_lock = PTHREAD_MUTEX_INITIALIZER;
    pthread_cond_t bank_condition = PTHREAD_COND_INITIALIZER;
    pthread_cond_t worker_condition = PTHREAD_COND_INITIALIZER;

    shared_data shared = {
        .accounts = accounts,
        .int_accounts = int_accounts,
        .transaction_counter_lock = &transaction_counter_lock,
        .bank_condition = &bank_condition,
        .worker_condition = &worker_condition,
        .transaction_counter = &transaction_counter,
        .active_workers = &active_workers,
    };

    
    pthread_t worker_threads[WORKER_THREADS];
    pthread_t bank;

    int transactions_per_worker = transaction_count / WORKER_THREADS;
    for (int i = 0; i < WORKER_THREADS; i++) {
        int start_index = i * transactions_per_worker;
        int end_index = (i == WORKER_THREADS - 1) ? transaction_count : start_index + transactions_per_worker;

        worker_args* args = malloc(sizeof(worker_args));
        args->shared = &shared;
        args->start_index = start_index;
        args->end_index = end_index;
        args->transactions = transactions;

        pthread_create(&worker_threads[i], NULL, worker_thread, args);
    }

    pthread_create(&bank, NULL, bank_thread, &shared);

  
    for (int i = 0; i < WORKER_THREADS; i++) {
        pthread_join(worker_threads[i], NULL);
    }
    pthread_join(bank, NULL);

    FILE* output_file = fopen("output.txt", "w");
    if (!output_file) {
        perror("Error creating output file");
        free(accounts);
        return 1;
    }

    for (int i = 0; i < int_accounts; i++) {
        fprintf(output_file, "Account %s: Balance = $%.2f\n", accounts[i].account_number, accounts[i].balance);
        pthread_mutex_destroy(&accounts[i].ac_lock);
    }

    fclose(output_file);


    for (int i = 0; i < transaction_count; i++) {
        free(transactions[i]);
    }
    free(transactions);
    free(accounts);

    printf("Part 3 completed successfully.\n");
    return 0;
}
	
