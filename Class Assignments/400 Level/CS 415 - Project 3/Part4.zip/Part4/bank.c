#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <unistd.h>
#include <time.h>
#include <sys/wait.h>
#include "account.h"
#include "string_parser.h"
int UPDATE_THRESHOLD = 5000;
typedef struct {
    char account_number[16];
    double puddles_bank_balance;
    double puddles_reward_rate;
} shared_account;

shared_account* shared_accounts; 
int shm_fd;  
int check_balance_count = 0;
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t cond_bank = PTHREAD_COND_INITIALIZER;
pthread_cond_t cond_worker = PTHREAD_COND_INITIALIZER;
int transactions_processed = 0;
int workers_finished = 0;
int worker_int = 1;
int int_accounts;
 account accounts[16];
typedef struct {
    account* accounts;
    int int_accounts;
    FILE *input_file;
} update_args;
FILE* auditor_file;


void auditor_log(const char* action, const char* account_number, double balance)
{
	
	time_t current_time = time(NULL);
	struct tm *time_info = localtime(&current_time);
	if(!auditor_file)
	{
		auditor_file = fopen("ledger.txt", "w");
	}
	char time_buffer[20];
	
	if (strcmp(action, "500th Check Balance") == 0)
	{
		fprintf(auditor_file, "%d Worker checked balance of to account %s. New Balance: %.2f %s\n", worker_int, account_number, balance, asctime(time_info));
		
	}
	else if (strcmp( action,"Duck Bank Update") == 0)
	{
		fprintf(auditor_file, "%d Applied Interest to account %s. New Balance: %.2f %s\n", worker_int, account_number, balance, asctime(time_info));
		
	}
	worker_int++;
	fflush(auditor_file);
}

void log_500(const char* account_number, double balance)
{
	check_balance_count++;
	if (check_balance_count % 500 == 0 || check_balance_count == 1)
	{
		auditor_log("500th Check Balance", account_number, balance);
	}
}
void process_transaction(char* transaction_line, account* accounts, int total_accounts) 
{
    parseing parsed = parser_string(transaction_line);

    if (parsed.int_command == 0) 
    {
        free_command(&parsed);
        return;
    }

    char operation_type = parsed.command_array[0][0];
    switch (operation_type) 
    {
        case 'D': 
            // Deposit case
            if (parsed.int_command == 4) 
            {
                char* src_account = parsed.command_array[1];
                char* password = parsed.command_array[2];
                double amount = atof(parsed.command_array[3]);
                for (int i = 0; i < total_accounts; i++) 
                {
                    if (strcmp(accounts[i].account_number, src_account) == 0 && strcmp(accounts[i].password, password) == 0) 
                    {
                        pthread_mutex_lock(&accounts[i].ac_lock);
                        accounts[i].balance += amount;
                        accounts[i].transaction_tracker += amount;
                        pthread_mutex_unlock(&accounts[i].ac_lock);
                        break;
                    }
                }
            }
            break;

        case 'W': 
            // Withdraw case
            if (parsed.int_command == 4) 
            {
                char* src_account = parsed.command_array[1];
                char* password = parsed.command_array[2];
                double amount = atof(parsed.command_array[3]);
                for (int i = 0; i < total_accounts; i++) 
                {
                    if (strcmp(accounts[i].account_number, src_account) == 0 && strcmp(accounts[i].password, password) == 0) 
                    {
                        pthread_mutex_lock(&accounts[i].ac_lock);
                        accounts[i].balance -= amount;
                        accounts[i].transaction_tracker += amount;
                        pthread_mutex_unlock(&accounts[i].ac_lock);
                        break;
                    }
                }
            }
            break;

        case 'T':  
            // Transfer case
            if (parsed.int_command == 5) 
            {
                char* src_account = parsed.command_array[1];
                char* password = parsed.command_array[2];
                char* dest_account = parsed.command_array[3];
                double amount = atof(parsed.command_array[4]);
                for (int i = 0; i < total_accounts; i++) 
                {
                    if (strcmp(accounts[i].account_number, src_account) == 0 && strcmp(accounts[i].password, password) == 0) 
                        {
                        for (int j = 0; j < total_accounts; j++) 
                        {
                            if (strcmp(accounts[j].account_number, dest_account) == 0) {
				pthread_mutex_lock(&accounts[j].ac_lock);
                                pthread_mutex_lock(&accounts[i].ac_lock);
                                accounts[i].balance -= amount;
                                accounts[j].balance += amount;
                                accounts[i].transaction_tracker += amount;
				//printf("%.2f\n", accounts[i].transaction_tracker);
                                pthread_mutex_unlock(&accounts[i].ac_lock);
				pthread_mutex_unlock(&accounts[j].ac_lock);
                                break;
                            }
                        }
                        break;
                    }
                }
            }
            break;

        case 'C':  
            // Check Balance case
            if (parsed.int_command == 3) 
            {
                char* src_account = parsed.command_array[1];
                char* password = parsed.command_array[2];
                for (int i = 0; i < total_accounts; i++) 
                {
                    if (strcmp(accounts[i].account_number, src_account) == 0 && strcmp(accounts[i].password, password) == 0) 
                    {
			log_500(src_account, accounts[i].balance);
                        //pthread_mutex_lock(&accounts[i].ac_lock);
			//printf("Account %s balance: $%.2f\n", accounts[i].account_number, accounts[i].balance);
			//pthread_mutex_unlock(&accounts[i].ac_lock);
                        break;
                    }
                }
            }
            break;

        default:
            fprintf(stderr, "Error: Invalid operation %c\n", operation_type);
            break;
    }

    free_command(&parsed);
}



void initialize_shared_memory(account* accounts, int total_accounts) {
    shm_fd = shm_open("/puddles_bank", O_CREAT | O_RDWR, 0666);
    if (shm_fd == -1) {
        exit(EXIT_FAILURE);
    }

    if (ftruncate(shm_fd, sizeof(shared_account) * total_accounts) == -1) {
        exit(EXIT_FAILURE);
    }

    shared_accounts = mmap(NULL, sizeof(shared_account) * total_accounts, PROT_READ | PROT_WRITE, MAP_SHARED, shm_fd, 0);
    if (shared_accounts == MAP_FAILED) {
        exit(EXIT_FAILURE);
    }

    for (int i = 0; i < total_accounts; i++) {
        strcpy(shared_accounts[i].account_number, accounts[i].account_number);
        shared_accounts[i].puddles_bank_balance = accounts[i].balance * 0.2;  
        shared_accounts[i].puddles_reward_rate = 0.02;  
    }
}

void update_puddles_balances(int total_accounts) {
    for (int i = 0; i < total_accounts; i++) {
	
        double add = shared_accounts[i].puddles_reward_rate * shared_accounts[i].puddles_bank_balance;
	shared_accounts[i].puddles_bank_balance += add;
	auditor_log("Puddle Bank Update", shared_accounts[i].account_number, shared_accounts[i].puddles_bank_balance);
    }
}


void* worker_function(void* args) {

    update_args* arguments = (update_args*)args;
    account* accounts = arguments->accounts;
    int total_accounts = arguments->int_accounts;
	FILE* input_file = arguments->input_file;
    char transaction_line[256];
    while(fgets(transaction_line, sizeof(transaction_line), input_file))
    {
	transaction_line[strcspn(transaction_line, "\n")] = '\0';

    pthread_mutex_lock(&mutex);

    while (transactions_processed >= UPDATE_THRESHOLD) {
        pthread_cond_wait(&cond_worker, &mutex);
    }
    pthread_mutex_unlock(&mutex);

	process_transaction(transaction_line, accounts, total_accounts);
    pthread_mutex_lock(&mutex);
    transactions_processed++;
	
    if (transactions_processed == UPDATE_THRESHOLD) {
        pthread_cond_signal(&cond_bank);
    }
    pthread_mutex_unlock(&mutex);
}
    pthread_mutex_lock(&mutex);
	workers_finished++;
	if (workers_finished == total_accounts)
	{
		pthread_cond_signal(&cond_bank);
	}
pthread_mutex_unlock(&mutex);
    return NULL;
}


void* update_balance(void* args) {
    update_args* arguments = (update_args*)args;
    account* accounts = arguments->accounts;
    int total_accounts = arguments->int_accounts;

    while (1) {
        pthread_mutex_lock(&mutex);
        while (workers_finished < total_accounts && transactions_processed < UPDATE_THRESHOLD) {
            pthread_cond_wait(&cond_bank, &mutex);
        }

        if (workers_finished == total_accounts && transactions_processed < UPDATE_THRESHOLD) {
            pthread_mutex_unlock(&mutex);
            break;
        }

       
        for (int i = 0; i < total_accounts; i++) {
		//printf("%lf\n", accounts[i].transaction_tracker);
            double reward = accounts[i].reward_rate * accounts[i].transaction_tracker;
            pthread_mutex_lock(&accounts[i].ac_lock);
            accounts[i].balance += reward;
            accounts[i].transaction_tracker = 0.0;
            pthread_mutex_unlock(&accounts[i].ac_lock);
	    auditor_log("Duck Bank Update", accounts[i].account_number, accounts[i].balance);
        }

        
        update_puddles_balances(total_accounts);

        transactions_processed -= UPDATE_THRESHOLD;
        pthread_cond_broadcast(&cond_worker);
        pthread_mutex_unlock(&mutex);
	
    
	}
    return NULL;
}

int main(int argc, char* argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s input_file\n", argv[0]);
        return EXIT_FAILURE;
    }

    FILE* input_file = fopen(argv[1], "r");
    if (!input_file) {
        perror("Error opening input file");
        return EXIT_FAILURE;
    }

    fscanf(input_file, "%d\n", &int_accounts);
    account* accounts = malloc(int_accounts * sizeof(account));
    if (!accounts) {
        perror("Error allocating accounts");
        fclose(input_file);
        return EXIT_FAILURE;
    }

    for (int i = 0; i < int_accounts; i++) {
        fscanf(input_file, "index %d\n", &i);
        fscanf(input_file, "%s\n", accounts[i].account_number);
        fscanf(input_file, "%s\n", accounts[i].password);
        fscanf(input_file, "%lf\n", &accounts[i].balance);
        fscanf(input_file, "%lf\n", &accounts[i].reward_rate);
        accounts[i].transaction_tracker = 0.0;
        pthread_mutex_init(&accounts[i].ac_lock, NULL);
    }
	
    initialize_shared_memory(accounts, int_accounts);
	
    pthread_t worker_threads[10];
    pthread_t bank_thread;

    update_args args = {accounts, int_accounts, input_file};

    for (int i = 0; i < 10; i++) {
        pthread_create(&worker_threads[i], NULL, worker_function, &args);
    }
    pthread_create(&bank_thread, NULL, update_balance, &args);

    for (int i = 0; i < 10; i++) {
        pthread_join(worker_threads[i], NULL);
	
    }
    for (int i = 0; i> int_accounts; i++)
	{
	pthread_cond_signal(&cond_bank);
	}
    pthread_join(bank_thread, NULL);

	FILE* duck_bank_output_file = fopen("output/output_part4_duck_bank.txt", "w");
if (duck_bank_output_file == NULL) {
        perror("Error opening duck bank file");
        return EXIT_FAILURE;
    }
	for (int i = 0; i < int_accounts; i++)
	{
		fprintf(duck_bank_output_file, "Account %d balance: $%.2f\n", i, accounts[i].balance);
	}
	
fclose(duck_bank_output_file);
	FILE* puddles_bank_output_file = fopen("output/output_part4_puddles_bank.txt", "w");
if (puddles_bank_output_file == NULL) {
        perror("Error opening puddles bank file");
        return EXIT_FAILURE;
    }
	for (int i = 0; i < int_accounts; i++)
	{
		fprintf(duck_bank_output_file, "Account %d balance: $%.2f\n", i, shared_accounts[i].puddles_bank_balance);
	}
	

    for (int i = 0; i < int_accounts; i++) {
        pthread_mutex_destroy(&accounts[i].ac_lock);
    }

    munmap(shared_accounts, sizeof(shared_account) * int_accounts);
    shm_unlink("/puddles_bank");
    
    fclose(puddles_bank_output_file);
    free(accounts);
    fclose(input_file);
    fclose(auditor_file);
    return 0;
}